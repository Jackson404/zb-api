(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/orderInfo/orderInfo"],{

/***/ 201:
/*!****************************************************************************************************!*\
  !*** C:/Users/lifei/project/zb-api/public/wechat/main.js?{"page":"pages%2ForderInfo%2ForderInfo"} ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
__webpack_require__(/*! uni-pages */ 1);
var _mpvuePageFactory = _interopRequireDefault(__webpack_require__(/*! mpvue-page-factory */ 11));
var _orderInfo = _interopRequireDefault(__webpack_require__(/*! ./pages/orderInfo/orderInfo.vue */ 202));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}
Page((0, _mpvuePageFactory.default)(_orderInfo.default));

/***/ }),

/***/ 202:
/*!*********************************************************************************!*\
  !*** C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _orderInfo_vue_vue_type_template_id_63691185___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orderInfo.vue?vue&type=template&id=63691185& */ 203);
/* harmony import */ var _orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./orderInfo.vue?vue&type=script&lang=js& */ 205);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./orderInfo.vue?vue&type=style&index=0&lang=css& */ 207);
/* harmony import */ var _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ 9);






/* normalize component */

var component = Object(_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _orderInfo_vue_vue_type_template_id_63691185___WEBPACK_IMPORTED_MODULE_0__["render"],
  _orderInfo_vue_vue_type_template_id_63691185___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 203:
/*!****************************************************************************************************************!*\
  !*** C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue?vue&type=template&id=63691185& ***!
  \****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_template_id_63691185___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/vue-loader/lib??vue-loader-options!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./orderInfo.vue?vue&type=template&id=63691185& */ 204);
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_template_id_63691185___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_template_id_63691185___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ 204:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue?vue&type=template&id=63691185& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "view",
    { staticClass: "body", staticStyle: { "min-height": "100vh" } },
    [
      _c("view", { staticClass: "title" }, [
        _c(
          "view",
          {
            staticClass: "name",
            staticStyle: {
              display: "flex",
              "flex-wrap": "nowrap",
              "align-items": "center"
            }
          },
          [
            _c(
              "text",
              {
                staticClass: "text",
                staticStyle: {
                  "font-size": "36rpx",
                  "max-width": "70%",
                  display: "block",
                  "margin-right": "20rpx",
                  color: "#333333"
                }
              },
              [_vm._v(_vm._s(_vm.item.name))]
            ),
            _vm.item.t_jr == 2
              ? _c("image", {
                  staticStyle: {
                    width: "30rpx",
                    height: "30rpx",
                    display: "inline-block"
                  },
                  attrs: {
                    src: "https://www.zhengbu121.com/statics/img/1.png",
                    mode: "widthFix",
                    "lazy-load": "true"
                  }
                })
              : _vm._e()
          ]
        ),
        _c(
          "view",
          {
            staticStyle: {
              display: "flex",
              height: "30px",
              "line-height": "30px"
            }
          },
          [
            _c(
              "view",
              {
                staticClass: "money",
                staticStyle: { color: "#0084FF", "font-size": "30rpx" }
              },
              [_vm._v(_vm._s(_vm.item.pay) + "元")]
            )
          ]
        )
      ]),
      _c(
        "view",
        {
          staticClass: "title1",
          staticStyle: {
            padding: "10rpx 0 20rpx 0",
            color: "#333333",
            "font-size": "28rpx"
          }
        },
        [_vm._v(_vm._s(_vm.item.companyName))]
      ),
      _c(
        "view",
        {
          staticClass: "title1 u-f-ac",
          staticStyle: { padding: "0 0 24rpx 0", color: "#363636" }
        },
        [
          _c("view", { staticClass: "u-list u-f-ac" }, [
            _c("image", {
              staticStyle: {
                height: "28rpx",
                width: "26rpx",
                display: "block"
              },
              attrs: { src: "../../static/xiao/experience.png", mode: "" }
            }),
            _vm.item.workExp == 0
              ? _c(
                  "view",
                  {
                    staticStyle: {
                      "font-size": "26rpx",
                      color: "#333333",
                      padding: "0 40rpx 0 20rpx"
                    }
                  },
                  [_vm._v("不限")]
                )
              : _c(
                  "view",
                  {
                    staticStyle: {
                      "font-size": "26rpx",
                      color: "#333333",
                      padding: "0 40rpx 0 20rpx"
                    }
                  },
                  [_vm._v(_vm._s(_vm.item.workExp))]
                )
          ]),
          _c("view", { staticClass: "u-list u-f-ac" }, [
            _c("image", {
              staticStyle: {
                height: "28rpx",
                width: "32rpx",
                display: "block"
              },
              attrs: { src: "../../static/xiao/education.png", mode: "" }
            }),
            _c(
              "view",
              {
                staticStyle: {
                  "font-size": "26rpx",
                  color: "#333333",
                  padding: "0 40rpx 0 20rpx"
                }
              },
              [_vm._v(_vm._s(_vm.item.education))]
            )
          ]),
          _c("view", { staticClass: "u-list u-f-ac" }, [
            _c("image", {
              staticStyle: {
                height: "28rpx",
                width: "26rpx",
                display: "block"
              },
              attrs: { src: "../../static/xiao/experience.png", mode: "" }
            }),
            _c(
              "view",
              {
                staticStyle: {
                  "font-size": "26rpx",
                  color: "#333333",
                  padding: "0 40rpx 0 20rpx"
                }
              },
              [_vm._v(_vm._s(_vm.item.age))]
            )
          ])
        ]
      ),
      _c(
        "view",
        { staticClass: "tagx u-f-ac" },
        _vm._l(_vm.item.labelIds, function(items, index) {
          return _c("view", { key: index, staticClass: "tagone" }, [
            _vm._v(_vm._s(items))
          ])
        })
      ),
      _c("view", { staticStyle: { height: "20px" } }),
      _c(
        "view",
        {
          staticClass: "address",
          staticStyle: { display: "flex", padding: "20px 0" }
        },
        [
          _c("image", {
            staticStyle: {
              width: "14px",
              height: "18px",
              display: "block",
              "margin-right": "10px"
            },
            attrs: { src: "../../static/xiao/location.png", mode: "" }
          }),
          _c(
            "view",
            {
              staticStyle: {
                "line-height": "40rpx",
                "word-wrap": "break-word",
                padding: "0px 0px 0 5px",
                flex: "1",
                "font-size": "26rpx",
                color: "#666666"
              }
            },
            [_vm._v(_vm._s(_vm.item.address))]
          )
        ]
      ),
      _c("view", { staticStyle: { height: "15px" } }),
      _vm._m(0),
      _c(
        "view",
        { staticClass: "content", staticStyle: { padding: "0px 0" } },
        [
          _c("rich-text", {
            staticStyle: {
              "line-height": "30px",
              color: "#666666",
              "font-size": "14px !important",
              "word-break": "break-word"
            },
            attrs: {
              nodes: _vm.item.positionRequirement,
              mpcomid: "3034cbc0-0"
            }
          })
        ],
        1
      ),
      _c("view", { staticStyle: { height: "50px" } }),
      _c(
        "button",
        {
          staticClass: "cu-btn bg-red margin-tb-sm lg",
          staticStyle: {
            width: "90%",
            background: "#0084FF",
            position: "fixed",
            bottom: "8px",
            left: "5%"
          },
          attrs: { "data-target": "Modal", eventid: "3034cbc0-0" },
          on: { tap: _vm.add }
        },
        [_vm._v("立刻投递")]
      )
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("view", { staticClass: "des u-f-ac" }, [
      _c("image", {
        staticStyle: { width: "40rpx", height: "37rpx" },
        attrs: { src: "../../static/xiao/prove.png", mode: "" }
      }),
      _c(
        "view",
        {
          staticStyle: {
            "padding-left": "40rpx",
            "font-size": "36rpx",
            color: "#333"
          }
        },
        [_vm._v("职位详情")]
      )
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ 205:
/*!**********************************************************************************************************!*\
  !*** C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_18_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/babel-loader/lib!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--18-0!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/vue-loader/lib??vue-loader-options!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./orderInfo.vue?vue&type=script&lang=js& */ 206);
/* harmony import */ var _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_18_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_18_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_18_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_18_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_18_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 206:
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--18-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(uni) {Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _default =








































































{
  data: function data() {
    return {
      CustomBar: this.CustomBar,
      modalName: null,
      modalName1: null,
      modalName2: null,
      radio: '男',
      radio1: '海军',
      picker: ['50岁', '49岁', '48岁', '47岁', '46岁', '45岁', '44岁', '43岁', '42岁', '41岁', '40岁', '39岁', '38岁', '37岁', '36岁', '35岁', '34岁', '33岁', '32岁', '31岁', '30岁', '29岁', '28岁', '27岁', '26岁', '25岁', '24岁', '23岁', '22岁', '21岁', '20岁', '19岁', '18岁', '17岁', '16岁'],
      index: -1,
      index1: -1,
      picker1: ['1年', '2年', '3年', '4年', '5年', '6年', '7年', '8年', '9年', '10年', '11年', '12年', '13年', '14年', '15年', '16年', '17年', '18年', '19年', '20年'],
      username: '',
      picker2: ['硕士', '博士', '本科', '专科', '高中', '初中'],
      index2: -1,
      index3: -1,
      picker3: ['3千元以下', '3千~5千', '5千~8千', '8千~1万', '1万元以上'],

      picker4: ['2019年', '2018年', '2017年', '2016年', '2015年', '2014年', '2013年', '2012年', '2011年', '2010年', '2009年', '2008年', '2007年', '2006年', '2005年', '2004年', '2003年', '2002年', '2001年', '2000年', '1999年', '1998年', '1997年', '1996年', '1995年', '1994年', '1993年', '1992年', '1991年', '1990年'],
      index4: -1,
      index5: -1,
      picker5: ['1年', '2年', '3年', '4年', '5年', '6年', '7年', '8年', '9年', '10年', '11年', '12年', '13年', '14年', '15年', '16年', '17年', '18年', '19年', '20年'],

      jineng: '',
      pingjia: '',
      phone: '',
      id: '',
      title: '',
      soldier: '',

      money: '',
      wk_year: '',
      education: '',
      experience: '',
      address: '',
      des: '',
      tag: [],
      tag1: '',
      tag2: '',
      tag3: '',
      work: '',
      rw_ns: '',
      year: '',
      item: [] };



  },
  onLoad: function onLoad(e) {
    var _this = this;
    _this.id = e.id;
    console.log(e);
    _this.getInfo();
  },
  methods: {
    getInfo: function getInfo() {
      var _this = this;

      uni.showLoading({ 'title': "加载中..." });
      uni.request({
        url: _this.apiServer + "/api/v1.PositionManagement/getDetail",
        method: 'POST',
        data: {

          'positionId': _this.id,
          accessToken: uni.getStorageSync('utoken') },


        header: { 'content-type': 'application/x-www-form-urlencoded' },
        success: function success(res) {


          var data = res.data.data;
          var status = res.data.status;
          console.log(data);

          _this.item = data.detail;



          uni.hideLoading();





        } });

    },
    add: function add() {
      //先获取有没有简历
      var _this = this;

      uni.showLoading({ 'title': "加载中..." });
      uni.request({
        url: _this.apiServer + "/api/v1.Resume/getResumeByUserId",
        method: 'POST',
        data: {
          "id_token": uni.getStorageSync('token'),
          'accessToken': uni.getStorageSync('utoken') },



        header: { 'content-type': 'application/x-www-form-urlencoded' },
        success: function success(res) {

          console.log(res);
          var data = res.data.data.list;
          var status = res.data.errorCode;
          uni.hideLoading();
          if (status == '0') {

            console.log(data.id);
            //投递简历
            _this.send(data.id);

          } else {

            uni.showModal({
              title: '提示',
              content: '请您先添加简历，然后在进行职位投递',
              success: function success(res) {
                if (res.confirm) {
                  //填写简历
                  uni.navigateTo({
                    url: '../jianli/jianliadd' });

                } else if (res.cancel) {
                  console.log('用户点击取消');
                }
              } });



          }

        } });




    },

    showModal: function showModal(e) {
      console.log(e);
      this.modalName = 'Modal';
    },
    send: function send(e) {
      var _this = this;
      // var openid =uni.getStorageSync('openid');
      console.log(_this.id);
      uni.showLoading({ 'title': "提交中..." });
      uni.request({
        url: _this.apiServer + "/api/v1.Resume/applyPosition",
        method: 'POST',
        data: {
          'id_token': uni.getStorageSync('token'),
          'positionId': _this.id,
          'accessToken': uni.getStorageSync('utoken') },

        header: { 'content-type': 'application/x-www-form-urlencoded' },
        success: function success(res) {

          console.log(res);
          var data = res.data.data;
          var status = res.data.errorCode;
          uni.hideLoading();
          if (status == '0') {
            //投递简历

            uni.showToast({
              title: '投递成功',
              icon: "none" });


          } else if (status == '-20000018') {
            uni.showToast({
              title: '已经申请过该职位',
              icon: "none" });

          } else if (status == '-10000005') {
            uni.showToast({
              title: '用户简历不存在',
              icon: "none" });

          }



        } });

    },
    hideModal: function hideModal(e) {
      this.modalName = null;
    },
    showModal1: function showModal1(e) {
      console.log(e);
      this.modalName1 = e.currentTarget.dataset.target;
    },
    showModal11: function showModal11(e) {

      if (this.username == '') {
        uni.showToast({
          title: '姓名不能为空',
          icon: "none" });


        return;
      }
      if (this.phone == '') {

        uni.showToast({
          title: '联系方式不能为空',
          icon: "none" });

        return;
      }


      this.modalName = null;
      this.modalName1 = e.currentTarget.dataset.target;
    },
    showModal12: function showModal12(e) {


      this.modalName1 = null;
      this.modalName2 = e.currentTarget.dataset.target;
    },
    showModal13: function showModal13(e) {
      console.log(e);
      this.modalName2 = null;
      var _this = this;
      uni.showLoading({ 'title': "加载中..." });


      if (_this.index4 != '-1') {
        var rw = _this.picker4[_this.index4];
        var rw_ns = _this.rw_ns;
        var bz = _this.radio1;
      } else {
        var rw = -1;
        var rw_ns = -1;
        var bz = -1;
      }



      uni.request({
        url: this.websiteUrl + "index/index",
        method: 'POST',
        data: {
          'token': 'api2018',
          'name': _this.username,
          'age': _this.radio,
          'year': _this.year,
          'work': _this.work,
          'education': _this.picker2[_this.index2],
          'money': _this.picker3[_this.index3],
          'skill': _this.jineng,
          'evaluate': _this.pingjia,
          'phone': _this.phone,
          'rw': rw,
          'rw_ns': rw_ns,
          'bz': bz },

        header: { 'content-type': 'application/x-www-form-urlencoded' },
        success: function success(res) {


          var data = res.data.data;
          var status = res.data.status;

          if (status == 'ok') {
            uni.hideLoading();

            uni.showModal({
              title: "提示",
              content: "简历添加成交，请投递",
              showCancel: false,
              confirmText: "确定" });

          }

        } });







    },
    hideModal1: function hideModal1(e) {
      this.modalName1 = null;
    },
    showModal2: function showModal2(e) {
      console.log(e);
      this.modalName2 = e.currentTarget.dataset.target;
    },
    hideModal2: function hideModal2(e) {
      this.modalName2 = null;
    },
    RadioChange: function RadioChange(e) {
      console.log(e);
      this.radio = e.detail.value;
    },
    RadioChange1: function RadioChange1(e) {
      console.log(e);
      this.radio1 = e.detail.value;
    },
    ChooseCheckbox: function ChooseCheckbox(e) {
      var items = this.checkbox,
      values = e.currentTarget.dataset.value;
      for (var i = 0, lenI = items.length; i < lenI; ++i) {
        if (items[i].value == values) {
          items[i].checked = !items[i].checked;
          break;
        }
      }
    },
    PickerChange: function PickerChange(e) {
      console.log(e);
      this.index = e.detail.value;
    },
    PickerChange1: function PickerChange1(e) {
      console.log(e);
      this.index1 = e.detail.value;
    },
    PickerChange2: function PickerChange2(e) {
      console.log(e);
      this.index2 = e.detail.value;
    },
    PickerChange3: function PickerChange3(e) {
      console.log(e);
      this.index3 = e.detail.value;
    },
    PickerChange4: function PickerChange4(e) {
      console.log(e);
      this.index4 = e.detail.value;
    },
    PickerChange5: function PickerChange5(e) {
      console.log(e);
      this.index5 = e.detail.value;
    } } };exports.default = _default;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ 17)["default"]))

/***/ }),

/***/ 207:
/*!******************************************************************************************************************!*\
  !*** C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_1_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_6_oneOf_1_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_css_loader_index_js_ref_6_oneOf_1_2_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_6_oneOf_1_3_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/mini-css-extract-plugin/dist/loader.js??ref--6-oneOf-1-0!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--6-oneOf-1-1!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/css-loader??ref--6-oneOf-1-2!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/postcss-loader/src??ref--6-oneOf-1-3!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/vue-loader/lib??vue-loader-options!../../../../../../Downloads/HBuilderX.0.1.47.20180823-alpha.full/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./orderInfo.vue?vue&type=style&index=0&lang=css& */ 208);
/* harmony import */ var _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_1_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_6_oneOf_1_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_css_loader_index_js_ref_6_oneOf_1_2_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_6_oneOf_1_3_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_1_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_6_oneOf_1_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_css_loader_index_js_ref_6_oneOf_1_2_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_6_oneOf_1_3_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_1_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_6_oneOf_1_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_css_loader_index_js_ref_6_oneOf_1_2_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_6_oneOf_1_3_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_1_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_6_oneOf_1_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_css_loader_index_js_ref_6_oneOf_1_2_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_6_oneOf_1_3_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_1_0_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_6_oneOf_1_1_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_css_loader_index_js_ref_6_oneOf_1_2_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_6_oneOf_1_3_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_vue_loader_lib_index_js_vue_loader_options_Downloads_HBuilderX_0_1_47_20180823_alpha_full_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_orderInfo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 208:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--6-oneOf-1-0!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--6-oneOf-1-1!./node_modules/css-loader??ref--6-oneOf-1-2!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-oneOf-1-3!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/lifei/project/zb-api/public/wechat/pages/orderInfo/orderInfo.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

},[[201,"common/runtime","common/vendor"]]]);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/orderInfo/orderInfo.js.map